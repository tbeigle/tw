=== Clover for WooCommerce ===
Contributors: ejankowski, lucasmpb
Tags:
Requires at least: 3.6
Tested up to: 3.9.2
Stable tag: 0.1

== Description ==

Our WooCommerce Connector allows store owners to easily manage their WordPress eCommerce site from the convenience of Clover. Products and inventory can be easily sync’d, and orders processed through a single merchant account. Bonus: no more reconciling your online sales with your books.

== Installation ==

Upload the plugin to your blog, then activate it.

You need WooCommerce activated to use this plugin.
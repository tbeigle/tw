<?php

namespace Wooclover\Admin\App;

// Exit if accessed directly 
if ( ! defined( 'ABSPATH' ) )
	exit;

class Dashboard {

	 

}

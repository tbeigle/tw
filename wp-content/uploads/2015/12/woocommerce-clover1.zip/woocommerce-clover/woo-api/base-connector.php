<?php

namespace Wooclover\WooApi;

// Exit if accessed directly 
if ( !defined( 'ABSPATH' ) )
	exit;

class BaseConnector {

	public function __construct () {
		;
	}

}
